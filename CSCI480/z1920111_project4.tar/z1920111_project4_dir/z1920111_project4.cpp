/********************************************************************
CSCI 480 - Assignment 4 - Semester (Fall) Year 2023
Programmer: Thomas Dela Pena
Section: 1
TA: Sai Dinesh Reddy Bandi
Date Due: 11-05-23
Purpose: In this assignment, we will solve the Reader-Writer problem using
the PThreads library. We will get to practice using semaphores in the 
PThreads library
*********************************************************************/
#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include <vector>
#include <iostream>

//global string
std::string globalstring = "All work and no play makes Jack a dull boy.";
const char* globalstringchar = globalstring.c_str();

//semaphores
sem_t rw_sem;	//used by readers and writers
sem_t cs_sem;	//used for protecting critical sections of readers


int readcount = 0; //readcount initialized to 0

void *reader_thread(void*);
void *writer_thread(void*);



int main(int argc, char *argv[])
{
	
	
	//get command line arguments
	if (argc != 3)
	{
    	std::cerr << "Usage: " << argv[0] << " <num_readers> <num_writers>";
    	return -1;
	}
	if (atoi(argv[1]) < 0) 
	{
    	fprintf(stderr,"%d must be>= 0\n",atoi(argv[1]));   
    	return -1;
	}
	if (atoi(argv[2]) < 0)
	{
		fprintf(stderr,"%d must be>= 0\n",atoi(argv[2]));   
    	return -1;
	}
	
	//assign arguments
	int rdNum = std::stoi(argv[1]);		//number of reader threads
	int wrNum = std::stoi(argv[2]);		//number of writer threads
	
	//initialization of semaphores
	sem_init(&rw_sem, 0, 1);
	sem_init(&cs_sem, 0, 1);
	
	//create reader and writer threads
	//initialize pthread variables
	std::vector<pthread_t> rdID(rdNum);
	std::vector<pthread_t> wrID(wrNum);
	  
  	//pthread_attr_t attr;   /* set of thread attributes */
  	
  	//create reader thread
  	for(long i = 0; i < rdNum; ++i)
  	{
  		if (pthread_create(&rdID[i], NULL, reader_thread, (void *)i)) {
    	std::cerr << "Error creating reader thread " << i << std::endl;
    	return 1;
}
	}
	
	//create writer thread
	for(long i = 0; i < wrNum; ++i)
	{
		if (pthread_create(&wrID[i], NULL, writer_thread, (void *)i) != 0) {
    	std::cerr << "Error creating reader thread " << i << std::endl;
    	return 1;
}
	}

	std::cout << "Created " << rdNum << " reader threads and " << wrNum << " writer threads." << std::endl;
	
	//wait for reader threads to finish
	for(int i = 0; i < rdNum; i++)
	{
		pthread_join(rdID[i], nullptr);
	}
	
	//wait for writer threads to finish
	for(int i = 0; i < wrNum; i++)
	{
		pthread_join(wrID[i], nullptr);
	}
	
	//cleanup and exit
	sem_destroy(&rw_sem);
	sem_destroy(&cs_sem);
	
	pthread_exit(0);
}


/**
*	reader_thread	reader thread reads a shared string and print the contents to the stdout.
*	 
*	@param	param	void pointer to the parameter passed when thread was created
*
*	@return	nothing
**/
void *reader_thread(void *threadid)
{
	//local variables
	long tid;
	tid = (long)threadid;
	
	while(globalstring.length() > 0)	//while string is not empty
	{
		sem_wait(&cs_sem);	//enter critical section
		readcount++;
		printf("Readcount increments to: %i\n", readcount);
		if(readcount == 1)
		{
			sem_wait(&rw_sem);	//first reader locks writer	
		}
		sem_post(&cs_sem);	//exit critical section
		
		//read and print global string
		//std::cout << "Reader " << tid << " is reading ... content" << std::endl;
		printf("Reader %ld is reading ... content: %s\n", tid, globalstringchar);
		
		sem_wait(&cs_sem);	//enter the critical section
		readcount--;
		printf("Readcount decrements to: %i\n", readcount);
		if(readcount == 0)
		{
			sem_post(&rw_sem);	//last reader to allow writers		
		}	
		sem_post(&cs_sem);	//exit critical section

		sleep(1);			//sleep for 1 sec
	}
	
	pthread_exit(nullptr);

	return 0;
}

/**
*	writer_thread	writes the same string reader thread reads
*	 
*	@param	param	void pointer to the parameter passed when thread was created
*
*	@return	nothing
**/
void *writer_thread(void *threadid)
{
	//local variables
	long tid;
	tid = (long)threadid;
	
	//loop until the string is empty
	while(globalstring.length() > 0)
	{
		sem_wait(&rw_sem);	//wait for read/writing semaphore
		
		//perform writing
		//std::cout << "Writer " << tid << " is writing..." << std::endl;
		printf("Writer %ld is writing...\n", tid);

		//remove last character of global string
		if(!globalstring.empty())
		{
			globalstring.pop_back();
			//std::cout << globalstring << std::endl;	//print modified string
		}
		
		sem_post(&rw_sem);	//signal read/writing semaphore

		//sleep for 1 sec
		sleep(1);
	}
	
	pthread_exit(nullptr);
}


