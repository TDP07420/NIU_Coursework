/********************************************************************
CSCI 480 - Assignment 2 - Semester (Fall) Year 2023
Programmer: Thomas Dela Pena
Section: 1
TA: Sai Dinesh Reddy Bandi
Date Due: 9-27-23
Purpose: This program will practice the use of fork() and several other
system calls to implement a microshell in C/C++, and practices the
FCFS CPU scheduling algorithm 
*********************************************************************/
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <fcntl.h>
#include <vector>
#include <string>
#include <cctype>

using namespace std;

void parse_line(char*, vector<string>&);
void fcfs_proc(vector<string>&);

int main(void)
{
	char buf[1024];
	pid_t pid;
	int status;

	//array to hold command tokens after parsing
	vector<string> commands;

	//arguments list
	//char *const arglist[4] = {"ls", "ps", "ls -l", NULL};


	//printf("%%");

	//prompt user to input command
	cout << "myshell>";

	//hold input in buf
	cin >> buf;

	/*for debugging: delete later*/
	cout << buf << endl;

	

	

	
	while(fgets(buf, 1024, stdin) != NULL)
	{
		buf[strlen(buf) -1] = 0;

		

		//if command is 'quit' or 'q'
		if(strcmp(buf, "quit") == 0 || strcmp(buf, "q")  == 0)
		{
			//close application
			exit(0);
		}

		
		if((pid = fork()) < 0)
		{
			//print an error message
			cerr << "fork error";
		}
		else if(pid == 0)
		{
			//child

			//parse command line
			parse_line(buf,commands);

			char* fr = strstr(buf, "<"); 		//char* variable for file redirection
			char* fcfs = strstr(buf, "fcfs");	//char* var for fcfs scheduling

			//if command is 'ls -l'
			if(strcmp(buf, "ls -l") == 0)
			{
				execlp("ls", "ls", "-l", (char*) NULL);
			}
			else if(fr)	//if command has '<' for file redirection
			{
				int fd = open(commands.back().c_str(), O_CREAT | O_WRONLY, 0644);		//file descriptor

				if(fd)	//file found
				{
					dup2(fd, STDOUT_FILENO); //copy fd to std out
					dup2(fd, STDERR_FILENO); //copy fd to std err
					close(fd);				 //close fd
				}
				else    //file not found
				{
					//print error message
					cerr << "file not found" << endl;
				}

				//execute command (min 3 max 5 arg)
				if(commands.size() == 3)
				{
					execlp(commands.at(0).c_str(), commands.at(0).c_str(),
					       commands.at(1).c_str(), commands.at(2).c_str(), (char*) NULL);
					cerr << "couldn't execute: " << buf << endl;
				}
				else if(commands.size() == 4)
				{
					execlp(commands.at(0).c_str(), commands.at(0).c_str(),
					       commands.at(1).c_str(), commands.at(2).c_str(),
						   commands.at(3).c_str(), (char*) NULL);
					cerr << "couldn't execute: " << buf << endl;
				}
				else if(commands.size() == 5)
				{
					execlp(commands.at(0).c_str(), commands.at(0).c_str(),
					       commands.at(1).c_str(), commands.at(2).c_str(),
						   commands.at(3).c_str(), commands.at(4).c_str(), (char*) NULL);
					cerr << "couldn't execute: " << buf << endl;
				}
			}
			else if(fcfs)	//buf contains 'fcfs' in input
			{
				fcfs_proc(commands);
			}
			else
			{

				//execute based on how many arguments is in commands(max 5)
				if(commands.size() == 1)
				{
					execlp(commands.at(0).c_str(), commands.at(0).c_str(), (char*) NULL);
					cerr << "couldn't execute: " << buf << endl;
				}
				else if(commands.size() == 2)
				{
					execlp(commands.at(0).c_str(), commands.at(0).c_str(),
					       commands.at(1).c_str(), (char*) NULL);
					cerr << "couldn't execute: " << buf << endl;
				}
				else if(commands.size() == 3)
				{
					execlp(commands.at(0).c_str(), commands.at(0).c_str(),
					       commands.at(1).c_str(), commands.at(2).c_str(), (char*) NULL);
					cerr << "couldn't execute: " << buf << endl;
				}
				else if(commands.size() == 4)
				{
					execlp(commands.at(0).c_str(), commands.at(0).c_str(),
					       commands.at(1).c_str(), commands.at(2).c_str(),
						   commands.at(3).c_str(), (char*) NULL);
					cerr << "couldn't execute: " << buf << endl;
				}
				else if(commands.size() == 5)
				{
					execlp(commands.at(0).c_str(), commands.at(0).c_str(),
					       commands.at(1).c_str(), commands.at(2).c_str(),
						   commands.at(3).c_str(), commands.at(4).c_str(), (char*) NULL);
					cerr << "couldn't execute: " << buf << endl;
				}
				exit(127);
			}
			
			
		}
		
		//parent*
		if((pid = waitpid(pid, &status, 0)) < 0)
		{
			cerr << "waitpid error";
		}
		
		//cout << "buf =" << buf << endl;
		

		//re-print the prompt
		cout << "myshell>";
	}
	
	//exit(0);
}

/*
* parse_line - read and parse the command line user has inputed in buf.
*
* @param  buffer  character array that holds the command line
* 	
* @return array holding contents of command line after parsing
*/
void parse_line(char* buffer,vector<string>& commands)
{
	//convert buffer to string
	string buffstring(buffer);

	//create delimiter for parsing
	string delimiter = " ";

	size_t pos = 0;
	std::string token;
	while ((pos = buffstring.find(delimiter)) != std::string::npos) 
	{
		//store substring into temp token
    	token = buffstring.substr(0, pos);

		//push back token into commands array
		commands.push_back(token);

		//erase process part of string to restart process
    	buffstring.erase(0, pos + delimiter.length());
	}

	//insert remainder of buffstring in commands
	commands.push_back(buffstring);

	
	return;
}

/*
*	fcfs_proc() - function to begin 'first come first serve' process
*
*	@param commands	vector array that holds parsed command line from user input
*
*	@return	nothing
*/
void fcfs_proc(vector<string>& commands)
{
	//declare variables
	int processes = 5;
	vector<int> cpu_burst;
	srand(10);	//set seed to 10

	int twt;	//total waiting time
	int awt;	//avg waiting time

	//check to see if commands declared processor qty
	if(commands.size() >= 2)
	{
		try
		{
			processes = stoi(commands.at(1).c_str());
		}
		catch(const std::exception& e)
		{
			std::cerr << e.what() << '\n';
		}	
	}

	//print header
	cout << "FCFS CPU scheduling simulation with " << processes << "processes." << endl;

	//create cpu burst values based on processes then store in array
	for(int i = 0; i < processes; i++)
	{
		cpu_burst.push_back(1 + (rand() % 100));	//rng 1-100
		
		//print cpu burst
		cout << "CPU burst: " << cpu_burst[i] << " ms" << endl;
	}

	twt = cpu_burst[0];

	//calculate total wait time
	for(size_t i = 1; i < cpu_burst.size() - 1 ; i++)
	{
		twt = twt + (twt + cpu_burst[i]);
	}

	//print twt
	cout << "total wait time: " << twt << " ms" << endl;

	//calculate average wait time
	awt = twt / processes;

	//print awt
	cout << "average wait time: " << awt << " ms" << endl;

	return;
}
