/********************************************************************
CSCI 480 - Assignment 1 - Semester (Fall) Year 2023
Programmer: Thomas Dela Pena
Section: 1
TA: Sai Dinesh Reddy Bandi
Date Due: 9-10 -23
Purpose: This program will answer questions regarding 'turing'. Program
will do this by reading files within the /proc/sys/kernel directory 
*********************************************************************/
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <vector>

using std::string;
using std::ifstream;
using std::cout;
using std::endl;
using std::size_t;
using std::setprecision;

//prototypes
string read_ostype(string);
string read_hostname(string);
string read_osrelease(string);
string read_version(string);

int read_proc(string);
int read_chip(string);
int read_uptime(string);

void sec_days(int);
void read_block(string, string);
void read_five(string);
void read_swap();

int main()
{
	//create strings for input fields for question A
	string osType, hostName, osRelease, version;
	
	//print out input fields for question A
	cout << "A. Questions about turing's OS" << endl;
	cout << "1. Turing's OS type is '" << read_ostype(osType) << endl;
	cout << "2. Turing's host name is " << read_hostname(hostName) << endl;
	cout << "3. Turing's os release is " << read_osrelease(osRelease) << endl;
	cout << "4. Turing's version is " << read_version(version) << endl;
	
	//create strings for input fields for question B
	string procCt, chipCt, uptimeSec;
	
	//print quesions for question B
	cout << "\nB. Questions about turing's processors" << endl;
	cout << "1. Turing has " << read_proc(procCt) << " processors." << endl;
	cout << "2. Turing has  " << read_chip(chipCt) << " physical chips." << endl;	
	cout << "3. Turing has been up for " << read_uptime(uptimeSec) << " seconds." << endl;
	cout << "4. Turing has been up for ";
	//results for B4
	sec_days(read_uptime(uptimeSec));
	
	//create strings for question C
	string blockProc;
	string key = "0";
	
	//print questions for question C
	cout << "\nC. Questions about processor 0" << endl;
	read_block(blockProc, key);
	
	//question D
	string statBlock;
	
	//print questions for D
	cout << "\nD. Questions about processor 5" << endl;
	read_five(statBlock);
	
	//question E
	read_swap();
    
    return 0;
}


/**
*	Read files from /proc/sys/kernel to obtain ostype
*
*   @params - str1 - string to hold read file
*
*	returns - string to hold ostype
***/
string read_ostype(string str1)
{	
	//read from text file
	ifstream osFile("/proc/sys/kernel/ostype");
	
	//read file line by line
	getline(osFile, str1);

	osFile.close();
	
	return str1;
}

/**
*	Read files from /proc/sys/kernel to obtain hostname
*
*   @params - str1 - string to hold read file
*
*	returns - string to hold hostname
***/
string read_hostname(string str1)
{	
	//read from text file
	ifstream nameFile("/proc/sys/kernel/hostname");
	
	//read file line by line
	getline(nameFile, str1);

	nameFile.close();
	
	return str1;
}

/**
*	Read files from /proc/sys/kernel to obtain osrelease
*
*   @params - str1 - string to hold read file
*
*	returns - string to hold osrelease
***/
string read_osrelease(string str1)
{	
	//read from text file
	ifstream releaseFile("/proc/sys/kernel/osrelease");
	
	//read file line by line
	getline(releaseFile, str1);

	releaseFile.close();
	
	return str1;
}

/**
*	Read files from /proc/sys/kernel to obtain version
*
*   @params - str1 - string to hold read file
*
*	returns - string to hold version
***/
string read_version(string str1)
{	
	//read from text file
	ifstream versionFile("/proc/sys/kernel/version");
	
	//read file line by line
	getline(versionFile, str1);

	versionFile.close();
	
	return str1;
}

/**
*	Read files from /proc/sys/kernel to obtain amount of processors
*
*   @params - str1 - string to hold read file
*
*	returns - int to hold processor count
***/
int read_proc(string str1)
{	
	//read from text file
	ifstream osFile("/proc/cpuinfo");
	
	size_t found;		//int used to find substring pos
	
	int foundct = 0;	//int used to count how many times substring has been found
	
	//read file line by line
	if(osFile.is_open())
	{
		while(osFile)
		{
			//reads file one line at a time
			getline(osFile, str1);
			
			//set string key to find 'processor'
			found = str1.find("processor");
			if(found!=std::string::npos)	//substring found
			{
				foundct += 1;	//increment by 1
			}
		}
	}
	
	//cout << "found = " << foundct << endl;
	

	osFile.close();
	
	return foundct;
}

/**
*	Read files from /proc/sys/kernel to obtain physical chips
*
*   @params - str1 - string to hold read file
*
*	returns - int to hold processor count
***/
int read_chip(string str1)
{	
	//read from text file
	ifstream osFile("/proc/cpuinfo");
	
	size_t pos = 0;		//size_t used to find substring pos
	
	int chipct = 0;	    //int used to count how many times phys id is found
	
	string currentId = "-1";	//string to hold current physical id
	
	//read file line by line
	if(osFile.is_open())
	{
		while(osFile)
		{
			//reads file one line at a time
			getline(osFile, str1);
			
			//set string key to find 'processor'
			pos = str1.find("physical id");
			if(pos!=std::string::npos)	//substring found
			{
				string sub = str1.substr(pos + 14); //string to get value after finding field label
				
				//determine if processor block has a new physical chip id
				if(currentId.compare(sub) != 0)
				{
					//change current id to new one from substring
					currentId = sub;
					
					//increment chipct
					chipct += 1;
				}
				
				//cout << "chip id(string) = " << sub << " chip ct = " << chipct << endl;
			}
		}
	}
	
	osFile.close();
	
	return chipct;
}

/**
*	Read files from /proc/sys/kernel to obtain uptime in seconds
*
*   @params - str1 - string to hold read file
*
*	returns - int to hold uptime
***/
int read_uptime(string str1)
{	
	//read from text file
	ifstream uptimeFile("/proc/uptime");
	
	int uptime = 0;	//int to hold uptime value
	
	//read file line by line
	getline(uptimeFile, str1);
	
	//size_t to find substring pos (uptime)
	size_t pos = str1.find(" ");
	if(pos != string::npos)	//substring found
	{
		uptime = stoi(str1.substr(0, pos));	//change substring found to int, then place into uptime
	}

	uptimeFile.close();
	
	return uptime;
}

/**
*	Convert secs into days
*
*	@params - sec1 - double holding value in seconds
*
*	returns - nothing
**/
void sec_days(int sec1)
{
	//convert to days
	int day = sec1 / (24 * 3600);
  
  	//convert to hours
    sec1 = sec1 % (24 * 3600);
    int hour = sec1 / 3600;
  
  	//convert to minutes
    sec1 %= 3600;
    int minutes = sec1 / 60;
  
    sec1 %= 60;
    int seconds = sec1;
    
    //print out results
    cout << day << " days, " << hour << " hours, "
    												  << minutes << " minutes, " << seconds 
    												  << " seconds " << endl;
}

/*
*	Function will read and answer questions about processor 0
*
*	@param - str1 - string to hold file
*			 key - string holding the key for processor block
*
**/
void read_block(string str1, string key)
{
	//read from text file
	ifstream blockFile("/proc/cpuinfo");
	
	size_t pos = 0;		//size_t used to find substring pos
	
	//string used to find certain input fields
	string procKey = "processor";
	string vendorKey = "vendor_id";
	string modelKey = "model name";
	string sizeKey = "address sizes";
	
	//read file line by line
	if(blockFile.is_open())
	{
		while(blockFile)
		{
			//reads file one line at a time
			getline(blockFile, str1);
			
			
			//set string key to find 'processor'
			pos = str1.find(procKey);
			if(pos!=std::string::npos)	//substring found
			{
				//string to get value after finding field label
				string sub = str1.substr(pos + (procKey.size()+3)); 
				
				//determine if processor block matches key
				if(key.compare(sub) != 0)
				{
					//field does not match key
					//end file loop
					return;	
				}
			}
			
			//vendor_id
			size_t vendorPos = str1.find(vendorKey);
			if(vendorPos!=std::string::npos)//vendor found
				{
					//put value in substring and print
					string vendor_id = str1.substr(vendorPos + (vendorKey.size()+3));
						
					cout << "1. Vendor ID for processor 0 is " << vendor_id << endl;
						
				}
			
			//model name
			size_t modelPos = str1.find(modelKey);
			if(modelPos!=std::string::npos) //model name found
			{
				//put value in substring and print
				string modelName = str1.substr(modelPos + (modelKey.size()+3));
				
				cout << "2. Model name for processor 0 is " << modelName << endl;
			}
			
			//physical size
			size_t sizePos = str1.find(sizeKey); 
			if(sizePos != std::string::npos)	//address sizes found
			{
				//find where string separates physical and virtual sizes
				size_t physPos = str1.find(",");
				if(physPos != std::string::npos)	//separation of sizes found
				{
					//print physical size
					string physSize = str1.substr(sizeKey.size()+3 ,physPos - sizeKey.size() - 3);
					
					cout << "3. Physical size is " << physSize << endl;
					
					//print virtual size
					string virtSize = str1.substr(physPos + 1);
					
					cout << "4. Virtual size is " << virtSize << endl;
					
				}
			}
				
		}
	}
	
	blockFile.close();
	
	return;
}

/*
*	Function to read and answer questions on processor 5
*
*	@param - str1 - string to hold file
*			 key - key that holds processor block
*
*	returns - nothing
*/
void read_five(string str1)
{
	//read from text file
	ifstream fiveFile("/proc/stat");
	
	size_t pos = 0;		//size_t used to find substring pos
	
	//string used to find certain input fields
	string procKey = "cpu5";
	
	//vector of strings to hold information on processor
	std::vector<string> procField;
	string delimiter = " ";		//delimiter to split and store information on proc 5
	
	//read file line by line
	if(fiveFile.is_open())
	{
		while(fiveFile)
		{
			//reads file one line at a time
			getline(fiveFile, str1);
			
			//cout << str1 << endl;
			
			//set string key to find 'cpu5'
			pos = str1.find(procKey);
			if(pos!=std::string::npos)	//processor 5 found
			{
				//split string holding proc 5 and store in array
				while((pos = str1.find(delimiter)) != std::string::npos)
				{
					//store value in temporary substr to put in array
					string temp = str1.substr(0,pos);
					
					//place substr into string array
					procField.push_back(temp);
					
					//erase inserted field from original string
					str1.erase(0, pos + delimiter.length());
				}	
			}			
		}
		
		//convert values into seconds and print out
		cout << "1. Time spent in user mode: " << stoi(procField[1]) / 100 << " seconds." <<endl; 
		cout << "2. Time spent in system mode: " << stoi(procField[3]) / 100 << " seconds." << endl;
		
		//store idle time value for conversion to days
		int idleTime =  stoi(procField[4]) / 100;
		cout << "3. Turing has been idle for " << idleTime << " seconds." << endl;
		cout << "4. Turing has been idle for ";
		sec_days(idleTime);
	}
	
	fiveFile.close();
	
	return;
}

/*
*	Function to read swaps and answer question for E
*
*	@param - str1 - string to hold file
*
*   return - nothing
*/
void read_swap()
{
	//string holding filename
	string str1;
	
	//read from text file
	ifstream swapFile("/proc/swaps");
	
	string swapSize;	//string to hold size info
	
	if(swapFile.is_open())
	{
		while(swapFile)
		{
			//read file line by line
			getline(swapFile, str1);
	
			//size_t to find substring pos (uptime)
			size_t pos = str1.find("/dev");
			if(pos != string::npos)	//substring found
			{
				swapSize = str1.substr(50, 8);	//change substring found to int, then place into uptime
				
				cout << "\nE. Swap size = " << stoi(swapSize) / 1000 << " MB" << endl;
			}
		}
	}

	swapFile.close();
	return;
}




