
/**********************************************************
* *
* CSCI 470/502 Assignment 2 Summer 2022 *
* *
* Developer(s): Thomas Dela Pena *
* Moses Mang*
* *
* Due Date: 06-24-22 *
* *
* Purpose: Create an Invoice class that a hardware store *
* might use to represent an invoice for an item sold. 
* Declares 5 different invoice instances of different 
* hardware store items.
**********************************************************/
import java.text.DecimalFormat;

public class InvoiceTest
{
    /*
     * Main method
     */
    public static void main(String[] args)
    {
        //Hardcode invoice instances to test.
        //Default constructor with no arguments
        Invoice invoice1 = new Invoice();
        //Hammer
        Invoice invoice2 = new Invoice("HM-32-2134", "Hammer", 5, 29.99);
        //Phillips Head
        Invoice invoice3 = new Invoice("PH-12-5768", "Phillips Head Screwdriver", 20, 9.99);
        //Light Switch
        Invoice invoice4 = new Invoice("LS-56-1324", "Light Switch", 5, 19.99);
        //Carpenter's Square
        Invoice invoice5 = new Invoice("CS-78-9988", "Carpenter's Square", 1, 13.99);
        //Cordless Drill
        Invoice invoice6 = new Invoice("AB-23-4312", "Cordless Drill", 10, 189.00);

        //String templates for printing invoice
        String part = "Part No.: ";
        String item = "Item Desc.: ";
        String quantity = "Quantity: ";
        String price = "Item Price: ";
        String subtotal = "Invoice Subtotal: ";

        //String pattern for Decimal format - $99,999,999.99
        String pattern = "$##,####,##0.00";

        //Decimal Format used of subtotal
        DecimalFormat invoiceFormat = new DecimalFormat(pattern);

        //Create array to hold diffrent invoice instances
        Invoice invoiceList[] = {invoice1, invoice2, invoice3, invoice4, invoice5, invoice6};

        //variable to hold the invoice amount
        double invoiceAmount;

        for(int i = 0; i < invoiceList.length; i++)
        {
            //Calculate invoice amount
            invoiceAmount = invoiceList[i].getInvoiceAmount(invoiceList[i].getQty(),
                                                            invoiceList[i].getPrice());
            
            //Print Format
            System.out.println("Invoice #" + (i + 1) + "\n");       //Print Invoice num
            System.out.printf("%18s %s%n%n", part, invoiceList[i].getPartNum());    //Print Part Number
            System.out.printf("%18s %s%n%n", item, invoiceList[i].getPartDesc());   //print Part Description
            System.out.printf("%18s %d%n%n", quantity, invoiceList[i].getQty());    //Print Part Quantity
            System.out.printf("%18s %.2f%n%n", price, invoiceList[i].getPrice());    //Print Item Price
            System.out.printf("%s %s%n%n", subtotal, 
                              invoiceFormat.format(invoiceAmount));                         //Print Invoice Subtotal
            System.out.println("*********************************\n");

        }




    }
}