
/**********************************************************
* *
* CSCI 470/502 Assignment 2 Summer Semester *
* *
* Class Name: Invoice *
* *
* Developer(s): Thomas Dela Pena *
* Moses Mang *
* *
* Purpose:  Represents an invoice for an item sold at 
*           a hardware store.*
* *
**********************************************************/


public class Invoice
{
    //declaring variables
    private String partNum;     //part number
    private String partDesc;    //part description
    
    private int qty;            //quantity of item being purchased
             
    private double priceItem;   //price per item

    /*
     *  Default constructor
     */
    public Invoice()
    {
        
    }

    /*
     *  Invoice() constructor
     * 
     *  @param partNum Part Number
     *  @param partDesc Part Description
     *  @param qty Quantity of part being purchased
     *  @param priceItem Price of the part per item
     */
    public Invoice(String partNum, String partDesc, int qty, double priceItem)
    {
        //initializes the four variables
        this.partNum = partNum;  
        this.partDesc = partDesc;
        
        //validating qty
        if(qty > 0)
            this.qty = qty;

        //validating priceItem
        if(priceItem > 0.0)
            this.priceItem = priceItem;
    }

    /*
     *  setpartNum set method for partNum
     *  
     *  @param partNum Part Number
     */
    public void setPartNum(String partNum)
    {
        this.partNum = partNum;
    }

    /*
     *  getpartNum get method for partNum
     * 
     *  @return partNum 
     */
    public String getPartNum()
    {
        return partNum;
    }

    /*
     *  setpartDesc set method for partDesc
     * 
     *  @param partDesc Part Description
     */
    public void setPartDesc(String partDesc)
    {
        this.partDesc = partDesc;
    }

    /*
     *  getpartDesc get method for partDesc
     * 
     *  @return partDesc
     */
    public String getPartDesc()
    {
        return partDesc;
    }

    /*
     *  setQty set method for qty
     * 
     *  @param qty Quantity of parts being purchased
     */
    public void setQty(int qty)
    {
        this.qty = qty;
    }

    /*
     *  getQty get method for qty
     *  
     *  @return qty
     */
    public int getQty()
    {
        return qty;
    }

    /*
     *  setPrice set method for priceItem
     * 
     *  @param priceItem Price of the part per item
     */
    public void setPrice(double priceItem)
    {
        this.priceItem = priceItem;
    }

    /*
     *  getPrice get method for priceItem
     * 
     *  @return priceItem
     */
    public double getPrice()
    {
        return priceItem;
    }

    /*
     *  getInvoiceAmount returns the product of the quantity and 
     *  price per item of the item in question.  
     *   
     *  @param qty Quantity of items being purchased
     *  @param priceItem Price of the part per item
     * 
     *  @return invoiceAmt product of qty and priceItem
     */
    public double getInvoiceAmount(int qty, double priceItem)
    {
        //declare invoice variable
        double invoiceAmt;

        //if variables are negative, set to 0
        if(qty < 0)
            qty = 0;
        else if(priceItem < 0.0)
            priceItem = 0.0;
        
        //calculate invoice of the product
        invoiceAmt = qty * priceItem;

        return invoiceAmt; 
    }
}