/**********************************************************
 *
 *  CSCI 470/502        Assignment 6	  	 Summer 2022
 *
 *  Developer(s): Thomas Dela Pena
 *  			  Moses Mang
 *
 *  Due Date: August 4, 2022
 *
 *  Purpose: A GUI-based Java application with which
 *  a travel agent could present options for travel
 *  destinations to a client who wants to redeem his or
 *  her accumulated frequent flyer miles
 *
 *********************************************************/
import java.io.File;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.Arrays;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import java.text.DateFormatSymbols;

public class MileRedeemerAppController {

    //Create an instance of the MileRedeemer class
    MileRedeemer mr1  = new MileRedeemer();

    //initialized variables from the controller skeleton in Scene builder
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ListView<String> destinationListView;

    @FXML
    private TextField enterMilesTextField;

    @FXML
    private TextField normalMilesTextField;

    @FXML
    private Button redeemMilesButton;

    @FXML
    private ListView<String> redeemMilesListView;

    @FXML
    private TextField remainingMilesTextField;

    @FXML
    private Button selectFileButton;

    @FXML
    private Spinner<String> selectMonthSpinnerField;

    @FXML
    private TextField superSaverDatesTextField;

    @FXML
    private TextField superSaverMilesTextField;

    @FXML
    private TextField upgradeCostTextField;

    /**
     * Action to perform when Redeem Miles button is pressed. Get the miles entered
     * as wel as month selected. Then call redeemMiles() function and display the
     * list of cities that a client can fly to.
     * @param event User has clicked Redeem Miles button
     */
    @FXML
    void redeemMilesButtonPressed(ActionEvent event)
    {
        //clear redeemMilesListView item when the button is pressed
        redeemMilesListView.getItems().clear();

        //variables for redeemMiles();
        int monthSelected = 0;
        int milesSelected = 0;

        //switch-case to convert month selected to int
        switch(selectMonthSpinnerField.getValue())
        {
            case "Jan":
                monthSelected = 1;
                break;
            case "Feb":
                monthSelected = 2;
                break;
            case "Mar":
                monthSelected = 3;
                break;
            case "Apr":
                monthSelected = 4;
                break;
            case "May":
                monthSelected = 5;
                break;
            case "Jun":
                monthSelected = 6;
                break;
            case "Jul":
                monthSelected = 7;
                break;
            case "Aug":
                monthSelected = 8;
                break;
            case "Sep":
                monthSelected = 9;
                break;
            case "Oct":
                monthSelected = 10;
                break;
            case "Nov":
                monthSelected = 11;
                break;
            case "Dec":
                monthSelected = 12;
                break;

        }

        //try catch to parse text entered into enterMilesTextField to int
        try
        {
            milesSelected = Integer.parseInt(enterMilesTextField.getText());
        }
        catch(NumberFormatException nfe)
        {
            System.out.println(nfe);
            System.out.println("Invalid Number Entered");
        }

        //code based off redeemMiles from Assign 4
        //call redeemMiles()
        String redeem[] = mr1.redeemMiles(milesSelected,monthSelected);

        //if redeemMiles() returns empty, client does not have enough miles
        if(redeem.length == 0)
        {
            redeemMilesListView.getItems().add("*** Your client has not accumulated enough Frequent Flyer Miles *** ");

            //display remaining miles
            remainingMilesTextField.setText(Integer.toString(mr1.getRemainingMiles()));
        }
        else
        {
            //has enough miles, display result of cities client can fly to
            redeemMilesListView.getItems().add("Your client's Frequent Flyer Miles can be used to redeem the following tickets:");

            for(String s: redeem)
            {
                redeemMilesListView.getItems().add(s);
            }

            //display remaining miles
            remainingMilesTextField.setText(Integer.toString(mr1.getRemainingMiles()));
        }
    }

    /**
     * Action to perform when select file button is pressed. A FileChooser() is used to
     * choose a file to read. A list of cities is displayed on destinationListView.
     * @param event Select file button is pressed
     */
    @FXML
    void selectFileButtonPressed(ActionEvent event)
    {
        //following link was used to help figure out what to do
        //https://docs.oracle.com/javase/8/javafx/user-interface-tutorial/file-chooser.htm
        FileChooser f = new FileChooser();
        File file = f.showOpenDialog(null);

        if(file == null)
        {
            System.out.println("No File Selected");
        }
        else
        {
            try
            {
                Scanner filescan = new Scanner(file);
                mr1.readDestinations(filescan);
                filescan.close();
            }
            catch (FileNotFoundException e)
            {
                System.out.println(e);
            }
        }

        //following link was used to help figure out what to do
        //https://jenkov.com/tutorials/javafx/listview.html
        for(Destination d: mr1.getDestinationArray())
        {
            //commented out sort by mileage in MileRedeemer.java to match example output
            destinationListView.getItems().add(d.getCity());
        }

        //Sort destinationArray now in order to calculate remaining miles
        Arrays.sort(mr1.getDestinationArray(), new MileageComparator());

        //following link was used to help figure out what to do
        //https://o7planning.org/11185/javafx-spinner
        ObservableList<String> months = FXCollections.observableArrayList
                (
                        "Dec", "Nov", "Oct", "Sep",
                        "Aug", "Jul", "Jun", "May",
                        "Apr", "Mar", "Feb", "Jan"
                );

        SpinnerValueFactory<String> valueFactory = new SpinnerValueFactory.ListSpinnerValueFactory<>(months);
        valueFactory.setValue("Jan");
        selectMonthSpinnerField.setValueFactory(valueFactory);

        //following link was used to figure out what to do
        // https://stackoverflow.com/questions/65222134/how-to-align-text-inside-a-spinner-to-center-in-javafx
        selectMonthSpinnerField.editorProperty().get().setAlignment(Pos.BASELINE_RIGHT);
    }

    /**
     * Show info on normal, supersaver, upgrade, and dates for a city that the user has
     * selected in the destinationListView
     * @param event Mouse has been clicked on selected city
     */
    @FXML
    void selectedCityClicked(MouseEvent event)
    {
        //following link was used to help figure out what to do
        // https://self-learning-java-tutorial.blogspot.com/2018/06/javafx-listview-get-selected-item.html

        String selectedItem = destinationListView.getSelectionModel().getSelectedItem();

        //Loop through destinationArray
        for(Destination d: mr1.getDestinationArray())
        {
            //if selected city matches city variable for Destination element, display the relevent info
            if(selectedItem.equals(d.getCity()))
            {
                normalMilesTextField.setText(Integer.toString(d.getNormalMiles()));
                superSaverMilesTextField.setText(Integer.toString(d.getSaverMiles()));
                upgradeCostTextField.setText(Integer.toString(d.getFirstClass()));
                superSaverDatesTextField.setText(getMonth(d.getStartMonth()) + " - " +
                        getMonth(d.getEndMonth()));
            }
        }
    }

    /**
     * Get the name of the month
     * @param month The number of the month
     * @return The name of the month
     */
    private String getMonth(int month)
    {
        //following link was used to help figure out what to do
        //https://stackoverflow.com/questions/1038570/how-can-i-convert-an-integer-to-localized-month-name-in-java#1038580
        return new DateFormatSymbols().getMonths()[month-1];
    }

    @FXML
    void initialize() {
        //initialized asserts were created from the controller skeleton from Scene Builder
        assert destinationListView != null : "fx:id=\"destinationListView\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert enterMilesTextField != null : "fx:id=\"enterMilesTextField\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert normalMilesTextField != null : "fx:id=\"normalMilesTextField\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert redeemMilesButton != null : "fx:id=\"redeemMilesButton\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert redeemMilesListView != null : "fx:id=\"redeemMilesListView\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert remainingMilesTextField != null : "fx:id=\"remainingMilesTextField\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert selectFileButton != null : "fx:id=\"selectFileButton\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert selectMonthSpinnerField != null : "fx:id=\"selectMonthSpinnerField\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert superSaverDatesTextField != null : "fx:id=\"superSaverDatesTextField\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert superSaverMilesTextField != null : "fx:id=\"superSaverMilesTextField\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert upgradeCostTextField != null : "fx:id=\"upgradeCostTextField\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";

    }

}
