/**********************************************************
 *                                                        
 *  CSCI 470/502        Assignment 4	  	 Summer 2022  
 *                                                        
 *  Developer(s): Thomas Dela Pena                              
 *  			  Moses Mang						  
 *                                                        
 *  Due Date: July 1, 2022                                
 *                                                        
 *  Purpose: A console-based Java application with which  
 *  a travel agent could present options for travel 	  
 *  destinations to a client who wants to redeem his or	  
 *  her accumulated frequent flyer miles				  
 *                                                        
 *********************************************************/


public class Destination
{
	// Declare private instance variables
	private String city;
	private int normal;
	private int superSaver;
	private int firstClass;
	private int startMonth;
	private int endMonth;
	
	/**
	 * Destination constructor that takes no arguments
	 */
	public Destination()
	{
		city = "";
		normal = 0;
		superSaver = 0;
		firstClass = 0;
		startMonth = 0;
		endMonth = 0;
	}
	
	/**
	 * 	A Destination constructor
	 * 	@param city Name of destination city
	 * 	@param normal Normal miles for a ticket
	 * 	@param superSaver "Super-saver" miles during the "off season" months
	 * 	@param firstClass Additional miles to upgrade to first class
	 * 	@param startMonth Start month of the "off season"
	 * 	@param endMonth End month of the "off season"
	 */
	public Destination(String city, int normal, int superSaver, int firstClass, int startMonth, int endMonth)
	{
		this.city = city;
		this.normal = normal;
		this.superSaver = superSaver;
		this.firstClass = firstClass;
		this.startMonth = startMonth;
		this.endMonth = endMonth;
	}
	
	/**
	 * 	Set the name of the destination city
	 * 	@param city The name of the destination city
	 */
	public void setCity(String city)
	{
		this.city = city;
	}
	
	/**
	 * 	Get the name of the destination city
	 * 	@return The name of the destination city
	 */
	public String getCity()
	{
		return city;
	}
	
	/**
	 * 	Set the normal miles required for a ticket
	 * 	@param normal Miles required
	 */
	public void setNormalMiles(int normal)
	{
		this.normal = normal;
	}
	
	/**
	 * 	Get the normal miles required for a ticket
	 * 	@return The miles required
	 */
	public int getNormalMiles()
	{
		return normal;
	}
	
	/**
	 * 	Set the miles required for a ticket during "off season" months
	 *	@param superSaver The miles required
	 */
	public void setSaverMiles(int superSaver)
	{
		this.superSaver = superSaver;
	}
	
	/**
	 * 	Get the miles required for a ticket during "off season" months
	 * 	@return The miles required
	 */
	public int getSaverMiles()
	{
		return superSaver;
	}
	
	/**
	 * 	Set the additional miles for upgrading from economy to first class
	 * 	@param firstClass The additional miles required for upgrading
	 */
	public void setFirstClass(int firstClass)
	{
		this.firstClass = firstClass;
	}
	
	/**
	 * 	Get the additional miles for upgrading from economy to first class
	 * 	@return The additional miles required for upgrading
	 */
	public int getFirstClass()
	{
		return firstClass;
	}
	
	/**
	 * 	Set the start month of the "off season"
	 * 	@param startMonth The start month of "off season"
	 */
	public void setStartMonth(int startMonth)
	{
		this.startMonth = startMonth;
	}
	
	/**
	 * 	Get the start month of the "off season"
	 * 	@return The start month of the "off season"
	 */
	public int getStartMonth()
	{
		return startMonth;
	}
	
	/**
	 * 	Set the end month of the "off season"
	 * 	@param endMonth The end month of the "off season"
	 */
	public void setEndMonth(int endMonth)
	{
		this.endMonth = endMonth;
	}
	
	/**
	 * 	Get the end month of the "off season"
	 * 	@return The end month of the "off season"
	 */
	public int getEndMonth()
	{
		return endMonth;
	}
}