/**********************************************************
 *
 *  CSCI 470/502        Assignment 6	  	 Summer 2022
 *
 *  Developer(s): Thomas Dela Pena
 *  			  Mose Mang
 *
 *  Due Date: August 4, 2022
 *
 *  Purpose: A GUI-based Java application with which
 *  a travel agent could present options for travel
 *  destinations to a client who wants to redeem his or
 *  her accumulated frequent flyer miles
 *
 *********************************************************/
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MilesRedeemerApp extends Application
{
    /**
     * Main of MileRedeemerApp
     * @param args Array of strings
     */
    public static void main(String[] args)
    {
        //create a MileRedeemerApp object and call its start method
        launch(args);
    }

    //based from example in assignment pdf
    @Override
    public void start(Stage stage) throws Exception
    {
        //Based off of tipCalculator from example code in Blackboard
        Parent root = FXMLLoader.load(getClass().getResource("MileRedeemerUI.fxml"));

        Scene scene = new Scene(root);
        stage.setTitle("Miles Redemption App");
        stage.setScene(scene);
        stage.show();
    }


}
