/**********************************************************
 *                                                        
 *  CSCI 470/502        Assignment 4	  	 Summer 2022  
 *                                                        
 *  Developer(s): Thomas Dela Pena                              
 *  			  Moses Mang						  
 *                                                        
 *  Due Date: July 1, 2022                                
 *                                                        
 *  Purpose: A console-based Java application with which  
 *  a travel agent could present options for travel 	  
 *  destinations to a client who wants to redeem his or	  
 *  her accumulated frequent flyer miles				  
 *                                                        
 *********************************************************/
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class MileRedeemer 
{
	// Array of destination objects
	private Destination [] destinationArray;
	private int remainingMiles;
	
	/**
	 *	Set the saved remaining miles
	 *	@param remainingMiles The saved remaining miles
	 */
	public void setRemainingMiles(int remainingMiles)
	{
		this.remainingMiles = remainingMiles;
	}

	/**
	 *	Get the saved remaining miles
	 * 	@return - The saved remaining miles
	 */
	public int getRemainingMiles()
	{
		return remainingMiles;
	}

	/**
	 * Set an array of Destination objects
	 * @param destinationArray - An array of Destination objects
	 */
	public void setDestinationArray(Destination[] destinationArray)
	{
		this.destinationArray = destinationArray;
	}

	/**
	 * Get an array of Destination objects
	 * @return An array of Destination objects
	 */
	public Destination[] getDestinationArray()
	{
		return destinationArray;
	}

	/**
	 *	Read and parse the destination data into an array of Destination objects
	 *	@param fileScanner - Scanner object to read data
	 */
	public void readDestinations(Scanner fileScanner)
	{
		/// Destination object variables
		String city, temp;
		int normal, superSaver, firstClass, startMonth, endMonth;
		ArrayList<Destination> destinationList = new ArrayList<Destination>();
		
		// loop till EOF
		while(fileScanner.hasNextLine())
		{
			temp = fileScanner.nextLine();										//read in entire line
			String[] tempArr = temp.split(";");							//split the string by semicolon
			
			String[] monthArr = tempArr[tempArr.length - 1].split("-");	//split months string by hyphen -

			//assign part of array into the object variables
			city = tempArr[0];
			
			//parse to int for miles variable
			normal = Integer.parseInt(tempArr[1]);
			superSaver = Integer.parseInt(tempArr[2]);
			firstClass = Integer.parseInt(tempArr[3]);
			//parse to int for month variable
			startMonth = Integer.parseInt(monthArr[0]);
			endMonth = Integer.parseInt(monthArr[1]);

			/*  Debugging - checking that the variables contain values since there is
			// no exception handing and input validation for this assignment
			System.out.println(city + " " + normal + " " + superSaver + " " + firstClass + " "
					+ startMonth + " " + endMonth);*/
			
			//create instance of Destination class
			Destination tempDestination = new Destination(city, normal, superSaver, firstClass, startMonth, endMonth);

			//add Destination object in ArrayList destinationList
			destinationList.add(tempDestination);

			// Code from the PDF, convert ArrayList to a normal, fixed-length array of objects
			destinationArray = (Destination[]) destinationList.toArray(
					new Destination[destinationList.size()]);		
		}
		// Sort destinationArray by mileage
		//Arrays.sort(destinationArray, new MileageComparator()); //commented out to match example output
	}
	
	/**
	 *	Loop through the array of Destination objects and create an array of String
	 *	objects from the city names
	 *	@return An array of the city names
	 */
	public String[] getCityNames()
	{
		//declare array of strings to hold city names
		String[] cityNames = new String[destinationArray.length];

		//loop through destinationArray
		for(int i = 0; i < destinationArray.length; ++i)
		{
			// use getCity from Destination to get city name, insert into cityNames array
			cityNames[i] = destinationArray[i].getCity();
		}

		//sort city names
		Arrays.sort(cityNames);

		return cityNames;
	}
	
	/**
	 *	Algorithm to redeem miles
	 *	@param miles - The total available miles
	 * 	@param month - The desired month of departure
	 * 	@return An array of String objects containing descriptions of redeemed tickets
	 */
	public String[] redeemMiles(int miles, int month)
	{
		//declare String array to hold possible redeemable tickets
		String[] redeemedTickets;

		//declare ArrayList for temp holders
		ArrayList<Destination> tempDest = new ArrayList<>();
		ArrayList<String> tempString = new ArrayList<>();


		//try to get tickets that travel the farthest
		//check to see if months of departure is within supersaver window
		for(Destination d: getDestinationArray())
		{
			if(month >= d.getStartMonth() && month <= d.getEndMonth())
			{
				//use "super-saver mileage"
				if(miles >= d.getSaverMiles())
				{
					//add destination to tempDest
					tempDest.add(d);

					//reduce mileage used for ticket
					miles -= d.getSaverMiles();
				}
				
			}
			else
			{
				//use normal mileage
				if(miles >= d.getNormalMiles())
				{
					//add destination to tempDest
					tempDest.add(d);

					//reduce mileage used for ticket
					miles -= d.getNormalMiles();
				}	
			}
		}

		//loop through tempDest to see if tickets can upgrade to first class
		for(Destination d: tempDest)
		{
			//if there are enough miles, upgrade to first class
			if(miles >= d.getFirstClass())
			{
				//put information of redeemable tickets for first class in tempString
				tempString.add("* A trip to " + d.getCity() + " in First Class");

				//reduce mileage used for ticket
				miles -= d.getFirstClass();
			}
			else
			{
				//put information of redeemable tickets for economy class in tempString
				tempString.add("* A trip to " + d.getCity() + " in Economy Class");
			}
		}

		//convert ArrayList tempString to String array redeemedTickets
		redeemedTickets = (String[]) tempString.toArray(new String[tempString.size()]);

		//set miles left into remainingMiles
		setRemainingMiles(miles);

		return redeemedTickets;
	}
	

}
