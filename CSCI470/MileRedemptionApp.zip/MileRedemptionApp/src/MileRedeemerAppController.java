import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.Spinner;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class MileRedeemerAppController {

    MileRedeemer mr1 = new MileRedeemer();

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ListView<?> destinationListView;

    @FXML
    private TextField enterMilesTextField;

    @FXML
    private TextField normalMilesTextField;

    @FXML
    private Button redeemMilesButton;

    @FXML
    private ListView<?> redeemMilesListView;

    @FXML
    private TextField remainingMilesTextField;

    @FXML
    private Button selectFileButton;

    @FXML
    private Spinner<?> selectMonthSpinnerField;

    @FXML
    private TextField superSaverDatesTextField;

    @FXML
    private TextField superSaverMilesTextField;

    @FXML
    private TextField upgradeCostTextField;

    @FXML
    void redeemMilesButtonPressed(ActionEvent event) {

    }

    @FXML
    void selectFileButtonPressed(ActionEvent event) {
        Stage newStage = null;
        start(newStage);
    }

    public void start(Stage stage)
    {
        FileChooser f = new FileChooser();
        f.showOpenDialog(stage);
    }

    @FXML
    void initialize() {
        assert destinationListView != null : "fx:id=\"destinationListView\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert enterMilesTextField != null : "fx:id=\"enterMilesTextField\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert normalMilesTextField != null : "fx:id=\"normalMilesTextField\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert redeemMilesButton != null : "fx:id=\"redeemMilesButton\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert redeemMilesListView != null : "fx:id=\"redeemMilesListView\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert remainingMilesTextField != null : "fx:id=\"remainingMilesTextField\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert selectFileButton != null : "fx:id=\"selectFileButton\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert selectMonthSpinnerField != null : "fx:id=\"selectMonthSpinnerField\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert superSaverDatesTextField != null : "fx:id=\"superSaverDatesTextField\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert superSaverMilesTextField != null : "fx:id=\"superSaverMilesTextField\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";
        assert upgradeCostTextField != null : "fx:id=\"upgradeCostTextField\" was not injected: check your FXML file 'MileRedeemerUI.fxml'.";

    }

}
