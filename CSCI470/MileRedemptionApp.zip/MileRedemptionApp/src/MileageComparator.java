/**********************************************************
 *                                                        *
 *  CSCI 470/502        Assignment 4	  	 Summer 2022  *
 *                                                        *
 *  Developer(s): Moses Mang                              *
 *  			  Thomas Dela Pena						  *
 *                                                        *
 *  Due Date: July 15, 2022                               *
 *                                                        *
 *  Purpose: A console-based Java application with which  *
 *  a travel agent could present options for travel 	  *
 *  destinations to a client who wants to redeem his or	  *
 *  her accumulated frequent flyer miles				  *
 *                                                        *
 *********************************************************/

import java.util.Comparator;

/**
 * Sort cities in order by descending normal miles
 */
public class MileageComparator implements Comparator<Destination>
{
	@Override
	public int compare(Destination d1, Destination d2) {
	return (d2.getNormalMiles() - d1.getNormalMiles()); }
}