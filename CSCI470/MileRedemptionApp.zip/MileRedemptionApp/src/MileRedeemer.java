/**********************************************************
 *                                                        *
 *  CSCI 470/502        Assignment 4	  	 Summer 2022  *
 *                                                        *
 *  Developer(s): Moses Mang                              *
 *  			  Thomas Dela Pena						  *
 *                                                        *
 *  Due Date: July 15, 2022                               *
 *                                                        *
 *  Purpose: A console-based Java application with which  *
 *  a travel agent could present options for travel 	  *
 *  destinations to a client who wants to redeem his or	  *
 *  her accumulated frequent flyer miles				  *
 *                                                        *
 *********************************************************/

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class MileRedeemer
{

	// MileRedeemer variables
	private Destination [] destinationArray;
	private int remainingMiles;

	/**
	 * Read and parse the destination data into an array of Destination objects
	 * @param fileScanner - Scanner object to read data
	 */
	public void readDestinations(Scanner fileScanner)
	{
		/// Destination object variables
		String city, temp;
		int normal, superSaver, firstClass, startMonth, endMonth;
		ArrayList<Destination> destinationList = new ArrayList<>();

		// loop till EOF
		while(fileScanner.hasNextLine())
		{
			// Read in entire line
			temp = fileScanner.nextLine();
			// Split string by semicolon ;
			String[] tempArr = temp.split(";");
			// Split last string using dash -
			String[] lastArr = tempArr[tempArr.length - 1].split("-");
			// assign array to various variables
			city = tempArr[0];
			//  parse to int for the miles and month variables
			normal = Integer.parseInt(tempArr[1]);
			superSaver = Integer.parseInt(tempArr[2]);
			firstClass = Integer.parseInt(tempArr[3]);
			startMonth = Integer.parseInt(lastArr[0]);
			endMonth = Integer.parseInt(lastArr[1]);

			// Create an instance of Destination class
			Destination tempDestination = new Destination(city, normal, superSaver, firstClass, startMonth, endMonth);
			// add Destination object to destinationList ArrayList
			destinationList.add(tempDestination);
			// Code from the PDF, convert ArrayList to a normal, fixed-length array of objects
			Destination[] tempArray = (Destination[]) destinationList.toArray(
					new Destination[destinationList.size()]);
			// set private variable destinationArray
			setDestinationArray(tempArray);
		}
		// Sort destinationArray by mileage
		Arrays.sort(getDestinationArray(), new MileageComparator());		///< trail and error, this works
		// close Scanner object
		fileScanner.close();
	}

	/**
	 * Loop through the array of Destination objects and create an array of String
	 * objects from the city names
	 * @return An array of the city names
	 */
	public String[] getCityNames()
	{
		// Array of String to hold city names
		String[] cityNames = new String[getDestinationArray().length];
		// loop through destinationArray
		for(int i = 0; i < getDestinationArray().length; ++i)
		{
			// get city name and put it in cityNames array
			cityNames[i] = getDestinationArray()[i].getCity();
		}
		// Sort cityNames alphabetically
		Arrays.sort(cityNames);
		return cityNames;
	}

	/**
	 * Algorithm to redeem miles
	 * @param miles - The total available miles
	 * @param month - The desired month of departure
	 * @return An array of String objects containing descriptions of redeemed tickets
	 */
	public String[] redeemMiles(int miles, int month)
	{
		String[] redeemedTickets;
		// Use ArrayList as size can be changed dynamically
		ArrayList<Destination> tempDest = new ArrayList<>();
		ArrayList<String> tempString = new ArrayList<>();

		// 1) try to get tickets that travel the farthest
		// loop through each destination object in destinationArray
		for(Destination d: getDestinationArray())
		{
			// 2) use "super-saver" mileage whenever possible
			// If month selected is month that super-saver mileage can be used
			if(month >= d.getStartMonth() && month <= d.getEndMonth())
			{
				if(miles >= d.getSaverMiles())
				{
					// Add destination to tempDest that client can fly to and decrement miles
					tempDest.add(d);
					miles -= d.getSaverMiles();
				}
			}
			// 3) try to display as many different tickets as possible given the information
			// Month selected is not a month that super-saver mileage can be used
			else
			{
				if(miles >= d.getNormalMiles())
				{
					// Add destination to tempDest that client can fly to and decrement miles
					tempDest.add(d);
					miles -= d.getNormalMiles();
				}
			}
		}
		// 4) determine if you can use the remaining mileage for upgrade
		// loop through each destination in tempDest that client can fly to
		for(Destination d: tempDest)
		{
			// If there are enough miles, upgrade to First Class
			if(miles >= d.getFirstClass())
			{
				// Put information about trip to eligible city in First Class into tempString
				tempString.add("* A trip to " + d.getCity() + " in First Class");
				miles -= d.getFirstClass();
			}
			else // client doest not have enough miles to upgrade, so only Economy
			{
				// Put information about trip to eligible city in Economy Class into tempString
				tempString.add("* A trip to " + d.getCity() + " in Economy Class");
			}
		}
		// Convert tempString to String array redeemedTickets
		redeemedTickets = (String[]) tempString.toArray(new String[tempString.size()]);
		// Set remaining miles
		setRemainingMiles(miles);
		return redeemedTickets;
	}

	/**
	 * Set the saved remaining miles
	 * @param remainingMiles The saved remaining miles
	 */
	public void setRemainingMiles(int remainingMiles)
	{
		this.remainingMiles = remainingMiles;
	}

	/**
	 * Get the saved remaining miles
	 * @return - The saved remaining miles
	 */
	public int getRemainingMiles()
	{
		return remainingMiles;
	}

	/**
	 * Set an array of Destination objects
	 * @param destinationArray - An array of Destination objects
	 */
	public void setDestinationArray(Destination[] destinationArray)
	{
		this.destinationArray = destinationArray;
	}

	/**
	 * Get an array of Destination objects
	 * @return An array of Destination objects
	 */
	public Destination[] getDestinationArray()
	{
		return destinationArray;
	}
}