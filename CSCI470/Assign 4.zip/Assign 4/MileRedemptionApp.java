/**********************************************************
 *                                                        
 *  CSCI 470/502        Assignment 4	  	 Summer 2022  
 *                                                        
 *  Developer(s): Thomas Dela Pena                            
 *  			  Moses Mang						  
 *                                                        
 *  Due Date: July 1, 2022                                
 *                                                        
 *  Purpose: A console-based Java application with which  
 *  a travel agent could present options for travel 	  
 *  destinations to a client who wants to redeem his or	  
 *  her accumulated frequent flyer miles				  
 *                                                        
 *********************************************************/

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class MileRedemptionApp {
	
	/**
	 * Main of MileRedemptionApp
	 * @param args	array of string arguments
	 * @throws IOException	IOException thrown if file not found 
	 */
	public static void main(String[] args) throws IOException 
	{
		//create an instance of MileRedeemer
		MileRedeemer mr1 = new MileRedeemer();

		//create string to hold file name
		String filename;

		//string array to hold redeemedTickets
		String redeem[];

		//create int to hold miles and months for user input
		int miles;
		int months;

		//create variables used for user loop
		boolean userInput = true;
		String userSelect;

		//create Scanner to read name file
		Scanner cs = new Scanner(System.in);
		System.out.print("Please enter the name of the file: ");
		filename = cs.next();

		//read file
		File openFile = new File(filename);
		Scanner readFile = new Scanner(openFile);
		mr1.readDestinations(readFile);

		//print header
		System.out.println("\n");
		System.out.println("----------------------------------------------------------------");
		System.out.println("       WELCOME TO THE JAVA AIRLINES MILES REDEMPTION APP        ");
		System.out.println("----------------------------------------------------------------\n");
		System.out.println("List of destination cities your client can travel to:\n");

		//print city names
		for(String s: mr1.getCityNames())
		{
			System.out.println(s);
		}
		System.out.println("\n----------------------------------------------------------------\n");

		//while loop for ticket
		while(userInput)
		{
			Boolean yesNo = true;
			//prompt user for accumulated Frequent Flyer Miles(FFM)
			System.out.print("Please enter you client's accumulated Frequent Flyer Miles: ");
			miles = cs.nextInt();

			//prompt user for month of departure
			System.out.print("\nPlease enter you client' month of departure (1-12): ");
			months = cs.nextInt();

			//call redeem miles
			redeem = mr1.redeemMiles(miles, months);

			//if redeemTicket array is empty, print output that client does not have enough miles
			if(redeem.length == 0)
			{
				System.out.println("\n*** Your client has not accumulated enough Frequent Flyer Miles ***");

				//print remaining miles
				System.out.println("\n Your client's remaining Frequent Flyer Miles: " + 
									mr1.getRemainingMiles());
			}
			//does not return empty, print output client's potential redeemed tickets
			else
			{
				System.out.println("\n*** Your client's Frequent Flyer Miles can be used to redeem the following tickets: \n" );

				//print out tickets
				for(String r: redeem)
				{
					System.out.println(r);
				}

				//print remaining miles
				System.out.println("\n Your client's remaining Frequent Flyer Miles: " + 
									mr1.getRemainingMiles());
			}
			System.out.println("\n----------------------------------------------------------------\n");

			//prompt user if they want to continue
			//will loop if input is not y/n
			while(yesNo)
			{
				System.out.print("Do you want to continue (y/n)? ");
				userSelect = cs.next();

				//exit program if user input is 'n' or 'N'
				if(userSelect.equalsIgnoreCase("n"))
				{
					yesNo = false;
					userInput = false;
				}
				//loop if user input is 'y' or 'Y'
				else if(userSelect.equalsIgnoreCase("y"))
				{
					yesNo = false;
					System.out.println("\n----------------------------------------------------------------\n");
				}
				
			}//end of user prompt loop
		}//end of user loop

		//print thank you output
		System.out.println("\n-------------------------------------------------------------------------");
		System.out.println("       THANK YOU FOR USING THE JAVA AIRLINES MILES REDEMPTION APP");
		System.out.println("-------------------------------------------------------------------------");

		//close Scanner
		cs.close();
	}

}
