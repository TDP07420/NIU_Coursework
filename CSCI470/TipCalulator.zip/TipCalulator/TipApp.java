/**********************************************************
* *
* CSCI 470/502 Assignment 3 Summer 2022 *
* *
* Developer(s): Thomas Dela Pena *
* Moses Mang*
* *
* Due Date: 07-01-22 *
* *
* Purpose: Develop a Java console app to calculate tips.
*          This class encapsulates the user interface of
*          the app.
**********************************************************/

import java.util.Scanner;
import java.text.DecimalFormat;


public class TipApp
{
    //declare TipCalculator object
    private TipCalculator tipCalc = new TipCalculator();

    //create scanner object
    private Scanner tipScan = new Scanner(System.in);

    /*
     *  Main Method
     */
    public static void main(String[] args)
    {
        //create an instance of TipApp
        TipApp app1 = new TipApp();
        
        //start of calculate tips
        app1.calculateTips();
    }

    /*
     *  calculateTips contains the logic for interacting with the user
     *  at the keyboard and displays the output of the app.
     * 
     *  @note will call other methods to extract parts needed for calculations
     */
    public void calculateTips()
    {
        //declare variables
        String userInput;                   //to hold answer for next bill
        String pattern = "$##,###,##0.00";  //pattern for decimal format
        
        double billTotal = 0.0;             //to hold bill total from function
        double share = 0.0;                 //to hold individual share
        
        boolean billLoop = true;            //loop for another bill
        boolean yesLoop = true;

        DecimalFormat billFormat = new DecimalFormat(pattern);

        while(billLoop)
        {
            //
            yesLoop = true;                 //reset to true for each loop
            //prompt for bill amount
            promptBill();
            //prompt for tip percent
            promptPercent();
            //prompt for party size
            promptSize();

            //Calculate Tip
            billTotal = tipCalc.getTotalBill(tipCalc.getPercent(), tipCalc.getBill());
            share = tipCalc.getIndividualShare(billTotal, tipCalc.getSize());

            //print output
            System.out.println("*** Your Bill ***\n");
            System.out.printf("Bill Amount: %s\n", billFormat.format(tipCalc.getBill()));
            System.out.printf("Tip Percentage: %d%%\n", tipCalc.getPercent());
            System.out.printf("Party Size: %d\n\n", tipCalc.getSize());
            System.out.printf("Total Bill (with tip): %s\n", billFormat.format(billTotal));
            System.out.printf("Share for Each Individual: %s\n", billFormat.format(share));
            
            
            while(yesLoop)
            {
                //prompt for another bill
                System.out.print("Another Bill? (y/n): ");
                userInput = tipScan.next();

                if(userInput.equals("y") || userInput.equals("Y"))
                {
                    billLoop = true;
                    yesLoop = false;
                }
                else if(userInput.equals("n") || userInput.equals("N"))
                {
                    System.out.println("Goodbye!");
                    billLoop = false;
                    yesLoop = false;
                }
                else
                {
                    System.out.print("Enter valid response - ");
                }
            }//end for another loop
        }//end of bill loop



        /*test print
        System.out.printf("Bill amount = %-7.2f%n", tipCalc.getBill());
        System.out.printf("Percent amount = %-5d%n", tipCalc.getPercent());
        System.out.printf("Party size = %-5d%n", tipCalc.getSize());
        System.out.printf("Total bill = %-7.2f%n", billTotal);
        System.out.printf("Individual share = %-7.2f%n", share);
        */
        
         
    }

    /*
     *  promptBill prompt for and read the bill amount
     */
    public void promptBill()
    {
        //declare double to hold bill amount
        double billAmt = 0.0;

        System.out.print("Enter the bill amount: ");
        while(true)
        {
            try
            {
                billAmt = Double.parseDouble(tipScan.next()); //record double input
                
                //check if double is positive
                if(billAmt < 0)
                {
                    System.out.print("Please enter a valid amount: ");
                }
                else
                {
                    tipCalc.setBill(billAmt);
                    break;  //break out of while loop
                }
            }
            catch(NumberFormatException nfe)
            {
                System.out.print("Please enter a valid amount: ");
            }
        }//end of bill loop
    }

    /*
     *  promptPercent prompt for and read the tip percentage
     */
    public void promptPercent()
    {
        //declare int to hold percentage
        int billPercent = 0;

        System.out.print("Enter your desired tip percentage (20 equals 20%): ");
        while(true)
        {
            try
            {
                billPercent = Integer.parseInt(tipScan.next()); //record double input
                
                //check if double is positive
                if(billPercent < 0)
                {
                    System.out.print("Please enter a valid tip percentage: ");
                }
                else
                {
                    tipCalc.setPercent(billPercent);
                    break;  //break out of while loop
                }
            }
            catch(NumberFormatException nfe)
            {
                System.out.print("Please enter a valid tip percentage: ");
            }
        }//end of percent loop
    }

    /*
     *  promptSize prompt for and read the party size
     */
    public void promptSize()
    {
        //declare int to hold party size
        int billSize = 0;

        System.out.print("Enter the size of your party: ");
        while(true)
        {
            try
            {
                billSize = Integer.parseInt(tipScan.next()); //record double input
                
                //check if double is positive
                if(billSize < 0)
                {
                    System.out.print("Please enter a valid party size: ");
                }
                else
                {
                    tipCalc.setSize(billSize);
                    break;  //break out of while loop
                }
            }
            catch(NumberFormatException nfe)
            {
                System.out.print("Please enter a valid party size: ");
            }
        }//end of size loop
    }
    
}