/**********************************************************
* *
* CSCI 470/502 Assignment 3 Summer Semester *
* *
* Class Name: Invoice *
* *
* Developer(s): Thomas Dela Pena *
* Moses Mang *
* *
* Purpose:  Encapsulates the tip calculation logic. May be
*           reused with a different interface in a future
*           assignment
**********************************************************/

public class TipCalculator
{
    //declare variables
    int percent = 20;    //tip percentage
    int partySize = 1;  //party size

    double billAmount = 0.0;  //bill amount

    /*
     *  setPercent set tip percentage
     * 
     *  @param percent tip percentage
     */
    public void setPercent(int percent)
    {
        this.percent = percent;
    }

    /*
     *  getPercent get tip percentage
     * 
     *  @return percent tip percentage
     */
    public int getPercent()
    {
        return percent;
    }

    /*
     *  setSize set party size
     * 
     *  @param partySize party size
     */
    public void setSize(int partySize)
    {
        this.partySize = partySize;
    }

    /*
     *  getSize get party size
     * 
     *  @return partySize party size
     */
    public int getSize()
    {
        return partySize;
    }

    /*
     *  setBill set bill amount
     * 
     *  @param billAmount bill amount
     */
    public void setBill(double billAmount)
    {
        this.billAmount = billAmount;
    }

    /*
     *  getBill get bill amount
     * 
     *  @return billAmount bill amount
     */
    public double getBill()
    {
        return billAmount;
    }

    /*
     *  getTotalBill computes and returns total bill(bill amount + tip)
     * 
     *  @param percent tip percentage
     *  @param billAmount bill amount
     * 
     *  @return totalBill total bill
     */
    public double getTotalBill(int percent, double billAmount)
    {
        //declare new variables
        double totalBill;               //total bill amount
        double percentDouble = percent;        //tip percentage to double
        double tipAmt;                  //tip amount

        //calculate tip
        tipAmt = (percentDouble / 100) * billAmount;

        //calculate total bill
        totalBill = billAmount + tipAmt;

        return totalBill;
    }

    /*
     *  getIndividualShare computes and returns value of an equal share
     *  of the total bill (total bill divided by party size)
     * 
     *  @param totalBill total bill
     *  @param partySize party size
     * 
     *  @return invShare individual share
     */
    public double getIndividualShare(double totalBill, int partySize)
    {
        //declare variable
        double invShare;     //individual share

        //calculate individual share
        invShare = totalBill / partySize;

        return invShare;
    }
}